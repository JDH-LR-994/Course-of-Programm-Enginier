#include <fstream>
#include <iostream>
#include <string.h>

char* func_for_c_string(char* destination,const char* source);

int main()
{
  const char INPUT_FILE[32] = "input.txt";
  std::ifstream input(INPUT_FILE);

  if (!input)
  {
    std::cout << "File " << INPUT_FILE << " cannot be opened" << '\n';
    exit(2);
  }

  const std::size_t LENGTH_MAX = 64;
  char source[LENGTH_MAX + 1];

  input.getline(source, LENGTH_MAX, '\n');  

  std::cout << "source: " << source << '\n';

  char destination[LENGTH_MAX + 1]{'\0'};

  const char OUTPUT_FILE[LENGTH_MAX + 1] = "output.txt";
  std::ofstream output(OUTPUT_FILE);
  if (!output)
  {
    std::cout << "File " << OUTPUT_FILE << "cannot be opened" << '\n';
    exit(2);
  }

  output << func_for_c_string(destination, source);
}

char* func_for_c_string(char* destination, const char* source)
{
  const char vowels[11] = "AaEeIiOoUu";
  std::size_t i = 0;
  std::size_t count;
  std::size_t count_dest = 0;
  while (source[i] != '\0'){
      count = 0;
      std::size_t j = 0;
      char symbol = source[i];
      while (vowels[j] != '\0'){
        if (vowels[j] == symbol){
          count++;
        }
        j++;
      }
      if (count != 1){
        std::cout << source[i];
        destination[count_dest] = source[i];
        count_dest++;
      }
      i++;
  }
  return destination;
}